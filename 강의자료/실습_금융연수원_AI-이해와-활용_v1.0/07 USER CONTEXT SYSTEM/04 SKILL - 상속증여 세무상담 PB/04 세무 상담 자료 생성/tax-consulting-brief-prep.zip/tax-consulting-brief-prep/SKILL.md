---
name: tax-consulting-brief-prep
description: create practical pre-consultation tax briefing materials and client-specific legal tax risk checklists for private banking and wealth management use. use when the user asks for a one-page tax summary, pre-meeting client briefing, key tax-saving points, immediate action items, or a structured legal and tax risk checklist based on a client's asset structure, family situation, and consultation goals. especially relevant for pb consultation preparation, client communication drafts, inheritance and gift discussions, wealth transfer review, real estate and investment tax review, and tax-risk screening with mandatory disclosure language and explicit assumptions.
---

# tax consulting brief prep

Follow this skill when the user wants a concise, work-ready tax consultation preparation document, a client-facing pre-brief, or a legal and tax risk checklist for pb or wealth-management use.

Focus on structured preparation materials, not long-form tax education. First organize the client facts and consultation objective, then produce a one-page summary, a risk checklist, or both. Always include the required disclosure language.

## scope

Use this skill for one, several, or all of the following:

- one-page pre-consultation tax summary
- pb consultation preparation memo
- client-facing summary of key tax-saving points
- immediate action-item list before or after consultation
- legal and tax risk checklist based on client asset structure
- combined briefing material plus checklist
- inheritance, gift, wealth transfer, real estate, investment, or ownership-related consultation preparation

Typical input topics may involve:

- cash
- real estate
- listed shares
- business ownership interests
- inheritance and gift concerns
- asset transfer planning
- investment and property tax concerns
- family structure and future transfer plans

If the user requests only the summary, prioritize the summary and keep the checklist optional.  
If the user requests only the checklist, prioritize risk identification and action recommendations.

## core objective

Produce a concise and structured output that a pb can use immediately for:

- pre-meeting preparation
- client advance sharing
- internal consultation note
- first-round issue spotting
- discussion agenda setting
- tax and legal risk screening

The output must be practical, short, and consultation-oriented.

## mandatory disclosure language

Always include all three of the following statements in the final output, without omission:

1. 본 분석은 참고용 시뮬레이션이며, 구체적 실행은 반드시 세무사·세무법인과의 개별 상담이 필요하다
2. 세법은 빈번하게 개정되므로, 최신 시행령·고시를 반드시 재확인 후 활용하라
3. 본 사례의 고객 정보는 가상의 예시이며, 실제 상담 시 정확한 자산 현황 파악이 선행되어야 한다

Do not paraphrase these beyond recognition. Preserve them clearly and explicitly.

## inputs

Use the client information provided by the user when available. Organize inputs into the following structure:

- client summary
- asset composition
- approximate asset size or distribution
- family structure or transfer plan
- consultation purpose
- major concerns
- requested tone: conservative or proactive
- requested deliverable: summary only, checklist only, or both

If the user provides incomplete information, do not stop. State what is missing and proceed with explicit assumptions.

## mandatory workflow

### 1. summarize the client facts first

Before writing the output, organize the known facts into a short structured summary.

Include, where available:

- client situation
- asset mix
- approximate scale
- family or transfer context
- consultation purpose
- key areas of concern

This summary should help a pb understand the case quickly.

### 2. identify missing information and state assumptions

If information is incomplete, identify the missing items that materially affect analysis.

Common missing items include:

- exact asset values
- acquisition dates
- ownership structure
- recipient details
- prior gifts
- debt burden
- intended timing of transfer or disposal
- whether holdings are personal or business-related

When facts are missing, proceed using clearly labeled assumptions.

Do not bury assumptions inside later sections. State them clearly.

### 3. determine output scope

Resolve the request into one of the following:

- one-page summary only
- risk checklist only
- combined package
- conservative framing
- proactive framing

If the request is broad, default to combined package: one-page summary plus risk checklist.

### 4. write the one-page summary in a fixed structure

If a summary is requested, always include these three sections:

- 고객 현황 요약
- 핵심 절세 포인트 3가지
- 즉시 실행 가능한 액션 아이템

These three sections are mandatory for the summary format.

Keep the summary concise and structured. It should read like a one-page consultation brief, not a long memo.

### 5. make the tax-saving points client-specific

For `핵심 절세 포인트 3가지`, do not give generic textbook items.

Each point must connect directly to:

- the client's asset mix
- the consultation goal
- the likely tax issue or planning opportunity
- a decision area that matters in consultation

Good tax-saving points usually identify:

- where tax concentration may occur
- where timing matters
- where ownership structure matters
- where transfer or holding strategy may change the result
- which issue deserves early review before execution

### 6. make action items immediately usable

For `즉시 실행 가능한 액션 아이템`, provide practical steps a pb or client can prepare right away.

Good action items include:

- collect specific documents
- confirm ownership and acquisition history
- verify family-transfer history
- review debt and collateral structure
- prepare valuation-related information
- separate short-term action from specialist-review action

Do not write vague action items such as:
- review carefully
- prepare consultation
- discuss strategy later

Make each action item concrete.

### 7. build the risk checklist in the required format

If a checklist is requested, use this structure:

| 리스크 항목 | 위험도(상/중/하) | 현재 상태 | 권고 조치 | 관련 법령 |

Each row must be specific enough to be checked or discussed.

The checklist must identify actual risks arising from the client's asset structure, purpose, or missing information.

### 8. score risk based on practical priority

Use 상 / 중 / 하 in a way that helps prioritization.

Consider risk level higher when:

- the issue could materially change tax burden
- the issue may create filing or reporting risk
- the issue could affect legality or execution feasibility
- the issue blocks meaningful planning until clarified
- the issue could lead to customer misunderstanding or unsuitable execution

Do not assign risk levels mechanically.

### 9. describe current status carefully

For the `현재 상태` column:

- use provided facts where available
- if facts are missing, explicitly say 확인 필요 or 가정 기준
- avoid false precision
- distinguish between confirmed status and assumed status

The current-status column must help the pb see what is known versus unknown.

### 10. make recommendation actions executable

For the `권고 조치` column, provide actions that can be taken in real workflow.

Good examples:
- 취득가액 및 보유기간 자료 확보
- 최근 증여 이력 확인
- 공동보유 여부 및 지분 구조 점검
- 예상 상속·증여 시점별 세무 시뮬레이션 재검토
- 고객 안내자료 문구 수정
- 세무사 검토 전 필요한 자료 목록 정리

Avoid abstract phrases.

### 11. name related laws at a useful level

For the `관련 법령` column, identify the most relevant law or regulation name where reasonably possible.

Examples may include:
- 상속세 및 증여세법
- 소득세법
- 법인세법
- 지방세법
- 국세기본법
- 해당 시행령 또는 관련 규정

If the exact legal anchor is uncertain from the limited facts, say the most likely governing law and note that detailed confirmation is needed.

### 12. preserve a reference-only tone

All outputs must maintain a planning and preparation tone, not a definitive legal or tax opinion.

Use wording such as:

- 참고용 요약
- 검토 필요
- 가정 기준
- 추가 확인 필요
- 잠정 판단
- 실행 전 개별 검토 필요

Do not promise tax savings or present legal conclusions as final.

### 13. append assumptions, limits, and required notices

If information is missing or important caution is needed, include short sections for:

- 전제조건
- 가정
- 확인 필요사항
- 한계

Always include the mandatory disclosure language in a visible final section.

## output rules

### default output order

If both summary and checklist are requested, use this order:

1. 고객 정보 및 상담 목적 요약
2. 가정 및 전제조건
3. 1페이지 요약 자료
4. 리스크 체크리스트
5. 확인 필요사항
6. 필수 고지 문구

If only summary is requested, still include assumptions and disclosure language.  
If only checklist is requested, still include client summary, assumptions, and disclosure language.

### one-page summary template

Use this baseline structure:

#### 고객 현황 요약
- [short structured bullets or short sentences]

#### 핵심 절세 포인트 3가지
1. [client-specific point]
2. [client-specific point]
3. [client-specific point]

#### 즉시 실행 가능한 액션 아이템
- [action 1]
- [action 2]
- [action 3]

Keep this compact and readable.

### risk checklist template

Use this exact column structure:

| 리스크 항목 | 위험도(상/중/하) | 현재 상태 | 권고 조치 | 관련 법령 |
|---|---|---|---|---|
| ... | ... | ... | ... | ... |

### mandatory final notice template

Always include this section at the end:

#### 필수 고지 문구
- 본 분석은 참고용 시뮬레이션이며, 구체적 실행은 반드시 세무사·세무법인과의 개별 상담이 필요하다
- 세법은 빈번하게 개정되므로, 최신 시행령·고시를 반드시 재확인 후 활용하라
- 본 사례의 고객 정보는 가상의 예시이며, 실제 상담 시 정확한 자산 현황 파악이 선행되어야 한다

Do not omit this section.

## validation checklist

Before finalizing, confirm all of the following:

- the summary includes 고객 현황 요약, 핵심 절세 포인트 3가지, and 즉시 실행 가능한 액션 아이템
- the checklist includes 리스크 항목, 위험도, 현재 상태, 권고 조치, and 관련 법령
- the tax-saving points are connected to the client facts
- the action items are concrete and usable
- the risk items are specific and checkable
- missing information and assumptions are stated
- the three mandatory disclosure statements are present in full
- the output does not sound like a final legal or tax opinion

If any required element is missing, revise before finalizing.

## risk-identification standard

When identifying risks, prioritize issues such as:

- unclear ownership structure
- prior gift or transfer history
- timing-sensitive transfer decisions
- valuation uncertainty
- mixed personal and business asset treatment
- inheritance or gift tax exposure
- disposal timing and capital-gains exposure
- family arrangement uncertainty
- document or evidence gaps
- law-change sensitivity

Do not create abstract risk rows that cannot be reviewed in practice.

## tone control

If the user asks for conservative framing:
- keep wording cautious
- emphasize confirmation steps
- avoid aggressive planning suggestions

If the user asks for proactive framing:
- still keep the reference-only tone
- prioritize action planning and issue spotting
- do not become overly aggressive or definitive

## recommended response pattern

Use this sequence unless the user requests another format:

1. client summary
2. assumptions
3. one-page summary
4. risk checklist
5. items requiring confirmation
6. mandatory notice section

### example structure

고객 정보 및 상담 목적 요약:
- ...
- ...

가정 및 전제조건:
- ...
- ...

#### 고객 현황 요약
- ...

#### 핵심 절세 포인트 3가지
1. ...
2. ...
3. ...

#### 즉시 실행 가능한 액션 아이템
- ...
- ...
- ...

| 리스크 항목 | 위험도(상/중/하) | 현재 상태 | 권고 조치 | 관련 법령 |
|---|---|---|---|---|
| ... | ... | ... | ... | ... |

확인 필요사항:
- ...
- ...

#### 필수 고지 문구
- 본 분석은 참고용 시뮬레이션이며, 구체적 실행은 반드시 세무사·세무법인과의 개별 상담이 필요하다
- 세법은 빈번하게 개정되므로, 최신 시행령·고시를 반드시 재확인 후 활용하라
- 본 사례의 고객 정보는 가상의 예시이며, 실제 상담 시 정확한 자산 현황 파악이 선행되어야 한다

## do not do

- do not write a long general tax essay
- do not omit assumptions when facts are incomplete
- do not give generic tax-saving points unrelated to the client
- do not make action items vague
- do not use abstract risk descriptions with no review value
- do not omit the three mandatory disclosure statements
- do not write as if giving a final legal or tax opinion
