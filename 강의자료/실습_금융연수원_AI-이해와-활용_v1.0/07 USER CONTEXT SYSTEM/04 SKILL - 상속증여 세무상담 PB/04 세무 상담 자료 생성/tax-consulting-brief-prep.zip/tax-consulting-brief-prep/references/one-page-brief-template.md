# One-Page Brief Template

Use this template when creating the pre-consultation summary.

## Required structure

### 고객 현황 요약
- Keep this to 3-5 bullets.
- Summarize asset mix, family context, and consultation purpose.
- Avoid narrative paragraphs unless the user explicitly wants prose.

### 핵심 절세 포인트 3가지
1. Tie each point to the client's actual facts.
2. Focus on decision areas, timing, ownership, or transfer structure.
3. Avoid generic textbook language.

### 즉시 실행 가능한 액션 아이템
- Prefer document collection, fact confirmation, and next-step preparation.
- Use action verbs.
- Keep each item short and usable.

## Good example pattern

### 고객 현황 요약
- 고객 자산은 부동산과 금융자산 비중이 높고, 가족 간 자산 이전 가능성이 있음.
- 상담 목적은 절세 포인트 확인과 향후 증여·상속 방향 점검에 있음.
- 일부 핵심 정보는 미확인 상태이므로 가정 기반 검토가 필요함.

### 핵심 절세 포인트 3가지
1. 부동산과 금융자산의 과세 구조가 다를 수 있어 이전 방식별 세부담 비교가 우선 필요함.
2. 보유기간과 취득가액 자료가 정리되지 않으면 양도·증여 시뮬레이션 정밀도가 크게 낮아질 수 있음.
3. 가족 구성과 과거 이전 이력에 따라 공제·누진효과 검토 포인트가 달라질 수 있음.

### 즉시 실행 가능한 액션 아이템
- 최근 5~10년 내 증여 또는 이전 이력 자료 확보
- 주요 자산별 취득가액, 보유기간, 명의 현황 정리
- 상담 전 가족관계와 이전 대상 우선순위 확인
