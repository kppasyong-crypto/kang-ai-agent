# Assumption Writing Guide

Use assumptions whenever client facts are incomplete.

## What to identify as missing

Common missing inputs:
- exact asset value
- acquisition date
- ownership structure
- prior gifts or transfers
- debt or collateral status
- recipient details
- timing of execution

## Writing rules

- Label assumptions clearly.
- Separate known facts from assumed facts.
- Keep assumptions practical and relevant to the output.
- Do not pretend assumptions are confirmed facts.

## Good examples

- 정확한 취득가액 자료가 없어, 현재는 대략적 보유 구조를 기준으로 검토함.
- 과거 증여 이력은 미확인 상태이므로, 공제 및 누진효과는 보수적으로 가정함.
- 이전 시점은 향후 1년 내 검토를 전제로 간략 시뮬레이션함.

## Tone rule

Use wording such as:
- 가정 기준
- 확인 필요
- 잠정 판단
- 추가 검토 필요

Avoid wording that sounds final or guaranteed.
