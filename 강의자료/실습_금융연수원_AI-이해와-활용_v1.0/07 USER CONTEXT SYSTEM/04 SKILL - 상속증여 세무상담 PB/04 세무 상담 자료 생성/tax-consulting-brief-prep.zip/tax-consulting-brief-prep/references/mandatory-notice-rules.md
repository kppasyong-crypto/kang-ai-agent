# Mandatory Notice Rules

These statements must appear in every final output without omission.

## Required notice block

#### 필수 고지 문구
- 본 분석은 참고용 시뮬레이션이며, 구체적 실행은 반드시 세무사·세무법인과의 개별 상담이 필요하다
- 세법은 빈번하게 개정되므로, 최신 시행령·고시를 반드시 재확인 후 활용하라
- 본 사례의 고객 정보는 가상의 예시이며, 실제 상담 시 정확한 자산 현황 파악이 선행되어야 한다

## Final check rule

Before sending the answer, verify all three sentences are present in full.
Do not shorten them, merge them, or rewrite them beyond recognition.

## Placement rule

- Put the notice block at the end of the output.
- Keep it visually separated from the main analysis.
- Include it even when the user asks for a very short answer.
