# Risk Checklist Example

Use the risk checklist to identify real review points, not abstract concerns.

## Required columns

| 리스크 항목 | 위험도(상/중/하) | 현재 상태 | 권고 조치 | 관련 법령 |
|---|---|---|---|---|

## Good examples

| 리스크 항목 | 위험도(상/중/하) | 현재 상태 | 권고 조치 | 관련 법령 |
|---|---|---|---|---|
| 과거 증여 이력 미확인으로 인한 공제·누진 구조 오판 가능성 | 상 | 최근 증여 이력 자료 미확인 | 최근 10년 내 이전 이력 확인 및 일정표 정리 | 상속세 및 증여세법 |
| 부동산 취득가액 자료 미정리로 양도·이전 시 세부담 추정 오류 가능성 | 상 | 일부 자산만 취득자료 확인 | 등기, 취득계약서, 취득세 자료 확보 | 소득세법, 지방세법 |
| 가족 간 공동보유 구조 불명확으로 이전 방식 비교의 정확도 저하 | 중 | 지분 구조 확인 필요 | 등기부등본 및 명의 구조 재확인 | 민법, 상속세 및 증여세법 |

## Poor examples to avoid

- 세무 검토 필요
- 자산 확인 필요
- 법적 위험 있음

These are too abstract and do not help the pb prioritize work.
