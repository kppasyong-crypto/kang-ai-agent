# comparison table example

Use this file to keep comparison tables parallel and decision-useful.

## scenario table template

| 전략명 | 실행 방법 | 예상 절세액(연) | 실행 난이도 | 소요 비용 | 유의사항 |
|---|---|---|---|---|---|
| 시나리오 a | 현 구조 내 즉시 실행 가능한 이전 방식 | 전제 기반 추정 범위 | 낮음 | 낮음 | 실행 시점과 자산가치 변동에 따라 효과 달라질 수 있음 |
| 시나리오 b | 분할 이전 또는 중기 이전 설계 | 전제 기반 추정 범위 | 중간 | 중간 | 다년 실행이 필요하며 수증자 분산 구조를 검토해야 함 |
| 시나리오 c | 가족법인 또는 구조 재편 포함 | 전제 기반 추정 범위 | 높음 | 높음 | 세무 외에 법무, 회계, 운영관리 부담이 발생할 수 있음 |

## transfer-method table template

| 이전 방법 | 이전 대상 자산 | 예상 세부담 | 절세 효과 | 실행 시 유의사항 |
|---|---|---|---|---|
| 생전 증여 | 현금 또는 지분 | 전제 기반 추정 | 이전 시점 분산 시 유리할 수 있음 | 자산 가치 변동과 수증자 구조가 핵심 |
| 상속 | 전체 자산 또는 특정 핵심 자산 | 전제 기반 추정 | 생전 이전 대비 통제 유지에 유리할 수 있음 | 사망 시점 집중 과세 가능성 검토 필요 |
| 분할 증여 | 금융자산, 지분, 일부 부동산 | 전제 기반 추정 | 시기 분산과 수증자 분산 효과 가능 | 장기 실행 관리 필요 |
| 가족법인 활용 | 지분, 수익자산 | 전제 기반 추정 | 구조적 이전 설계 가능 | 법률, 세무, 회계, 운영 리스크 동시 검토 필요 |

## writing rules

- Keep columns comparable across rows.
- Use parallel sentence structure.
- Prefer indicative ranges over false precision.
- Make caution points specific to the method, not generic.
