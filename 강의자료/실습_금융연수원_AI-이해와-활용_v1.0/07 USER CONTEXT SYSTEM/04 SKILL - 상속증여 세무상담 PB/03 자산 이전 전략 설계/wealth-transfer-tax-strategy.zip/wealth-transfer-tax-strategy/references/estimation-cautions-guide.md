# estimation cautions guide

Use this guide whenever the response includes estimated tax burden or estimated tax-saving figures.

## core rule

Treat all figures as planning estimates unless unusually complete case data is available.

## required practices

- State the main assumptions behind the estimate.
- Prefer ranges when valuation, timing, or ownership facts are incomplete.
- Distinguish annual saving from total life-cycle tax effect.
- Explain the mechanism of advantage, not just the number.
- Mention where specialist review is still needed.

## wording examples

Preferred:
- indicative estimate under stated assumptions
- rough planning range, not a filing-ready amount
- may vary materially by valuation, timing, and ownership history
- requires detailed tax review before execution

Avoid:
- final tax amount
- exact tax saving
- guaranteed reduction
- definitive optimal strategy

## common uncertainty drivers

- asset valuation uncertainty
- recipient count and relationship
- timing of transfer
- ownership history and acquisition cost
- legal feasibility of structural options
- later law or policy change
