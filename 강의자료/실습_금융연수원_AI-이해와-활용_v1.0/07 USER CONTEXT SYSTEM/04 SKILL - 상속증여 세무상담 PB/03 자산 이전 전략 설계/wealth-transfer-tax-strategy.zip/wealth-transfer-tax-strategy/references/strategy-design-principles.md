# strategy design principles

Use this guide when designing client-specific wealth transfer strategies.

## objective

Build strategies that are clearly differentiated by planning horizon, complexity, and feasibility.

A strong output should help the user compare:

- tax logic
- implementation burden
- timing sensitivity
- legal and operational friction
- fit with client posture

## scenario separation rules

### scenario a: conservative

Use when the client wants immediate action with low disruption.

Typical traits:
- existing ownership structure preserved
- minimal legal setup
- limited number of transfer actions
- easy to explain and execute

### scenario b: active

Use when the client accepts a multi-year plan for better efficiency.

Typical traits:
- phased gifting
- transfer timing design
- recipient segmentation
- stronger tax planning than scenario a

### scenario c: comprehensive

Use when the client is open to structural change.

Typical traits:
- family corporation review
- broader ownership restructuring
- tax, legal, accounting, and governance coordination
- higher maintenance burden

## practical design rules

- Do not let all scenarios rely on the same transfer mechanic.
- Explain why each route may be more or less suitable for the specific client facts.
- Treat tax efficiency and execution feasibility as separate axes.
- Include a structural option only when it is realistic to discuss.
- When client information is thin, reduce numerical precision and emphasize assumptions.

## client-fit prompts

Use these framing checks:

- Does the client want simplicity or optimization?
- Is the transfer intended now, over time, or at death?
- Is control retention important?
- Are family governance issues likely?
- Is the client willing to absorb advisory, legal, or maintenance cost?
