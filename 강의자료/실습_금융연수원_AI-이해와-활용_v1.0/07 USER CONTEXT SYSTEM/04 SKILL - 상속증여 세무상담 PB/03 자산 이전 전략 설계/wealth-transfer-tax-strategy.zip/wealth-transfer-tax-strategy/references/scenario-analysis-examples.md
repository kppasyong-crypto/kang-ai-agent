# scenario analysis examples

Use these examples to keep scenario outputs concrete and differentiated.

## good pattern

### scenario a example shape
- Execute a limited near-term gift within the current ownership structure.
- Focus on simplicity and immediate feasibility.
- Present low to medium cost and low execution burden.

### scenario b example shape
- Split the target transfer across multiple years and recipients.
- Emphasize timing discipline and staged execution.
- Present medium difficulty and stronger planning effect than scenario a.

### scenario c example shape
- Review family corporation or structural ownership design.
- Explain setup cost, compliance burden, and governance issues.
- Present high difficulty and high caution even when tax efficiency appears attractive.

## weak pattern to avoid

- All three scenarios differ only by transfer amount.
- All three scenarios repeat the same caution points.
- Scenario c claims broad tax savings without addressing maintenance or substance risk.
- Numerical estimates are presented as exact tax outcomes.

## useful phrasing

Good:
- best for clients prioritizing immediate execution with low disruption
- more efficient if the client can commit to a three-year transfer schedule
- potentially broader planning benefit, but only if governance and maintenance burden are acceptable

Avoid:
- recommended strategy
- optimal in all cases
- guaranteed tax saving
