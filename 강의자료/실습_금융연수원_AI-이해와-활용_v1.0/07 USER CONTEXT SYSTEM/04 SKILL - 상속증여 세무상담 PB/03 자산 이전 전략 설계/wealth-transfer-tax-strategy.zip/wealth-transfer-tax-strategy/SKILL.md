---
name: wealth-transfer-tax-strategy
description: design and compare practical korean wealth transfer tax strategies based on a client's asset profile, transfer goals, family structure, and planning horizon. use when the user asks for gift versus inheritance comparison, wealth transfer scenarios, tax-burden comparison tables, client-specific tax saving strategies, pb-ready transfer planning drafts, or structured alternatives such as conservative, active, and structural strategies including family corporation review. especially relevant for private banking, wealth management, inheritance planning, gift planning, and client proposal drafting under current tax rules with explicit assumptions and limitations.
---

# wealth transfer tax strategy

Follow this skill when the user wants a practical client-ready draft for korean wealth transfer planning, especially for gift, inheritance, phased transfer, or structural transfer options.

Focus on planning design, comparison, and implementation logic. Do not give only generic tax explanations. First organize the client's facts and assumptions, then build differentiated scenarios, compare expected tax burden and execution difficulty, and explain practical cautions.

## scope

Use this skill for one, several, or all of the following:

- gift versus inheritance comparison
- client-specific wealth transfer strategy design
- phased transfer planning
- tax-burden comparison by transfer method
- conservative / active / structural planning alternatives
- family corporation review as part of transfer planning
- pb-ready briefing or client proposal draft for transfer strategy

Typical asset types in scope include:

- cash
- real estate
- listed shares
- unlisted shares
- business ownership interests
- financial investments
- mixed family wealth portfolios

If the user asks for one specific method only, stay focused on that method and compare it only as needed for context.

## core objective

Produce a structured draft that a pb or wealth manager can use immediately for:

- first-round client consultation
- transfer strategy comparison
- internal discussion with tax or legal specialists
- briefing notes for client proposals
- explanation of trade-offs between different transfer routes

The result must help the user compare not only tax burden, but also:

- execution feasibility
- planning horizon
- difficulty
- cost
- operational and legal caution points
- which client profile each route fits best

## inputs

Use the client information provided by the user when available. Organize inputs into the following structure:

- asset composition
- total asset size
- target asset for transfer
- family structure and intended recipients
- holding period or desired transfer timing
- client risk posture or preference
- willingness to accept structural change
- whether the user wants gift-focused, inheritance-focused, or mixed analysis
- whether the user wants annual tax saving focus, total tax burden focus, or implementation focus

If the user provides incomplete information, do not stop. State the missing items and proceed with explicit assumptions.

## mandatory workflow

### 1. organize client facts first

Before proposing strategies, summarize the known client facts in a short structured block.

Include, where available:

- assets currently held
- major transfer candidates
- estimated asset values
- potential recipients
- expected timing
- client posture: conservative or aggressive
- structural options allowed or not allowed

If information is missing, explicitly identify the missing variables that could materially affect the result.

### 2. state assumptions before analysis

If data is incomplete, define the assumptions used for planning.

Common assumption areas include:

- approximate asset values
- recipient count and relationship
- ownership and acquisition timing
- whether current tax law is applied without future legal change
- whether transfer is assumed to happen now, within 3 years, or at death
- whether valuation discounts, liquidity constraints, or legal setup constraints are ignored or included at a high level

Never hide assumptions inside the table. State them clearly before or after the main output.

### 3. confirm the planning frame

Resolve the request into one of the following:

- gift-centered planning
- inheritance-centered planning
- comparison of multiple transfer methods
- scenario design by risk posture
- structural planning including family corporation
- rough estimation focus
- qualitative comparison focus

If the request is broad, default to three scenarios plus one comparison table.

### 4. use current tax-law framing

Base the analysis on current korean tax rules as understood at the time of response.

When legal or tax treatment depends on detailed facts not provided, say so clearly.

If numerical estimates are included, present them as planning estimates, not filing-ready tax calculations.

Use language such as:

- estimated under stated assumptions
- rough planning comparison
- indicative range, not final filing amount
- requires specialist review for final implementation

Do not present estimated tax numbers as definitive liabilities.

### 5. design three differentiated scenarios by default

Unless the user requests a narrower format, provide the following three scenario types:

#### scenario a: conservative

This must be the most immediately executable option within the current structure.

Characteristics:
- minimal structural change
- lower execution burden
- suitable for near-term implementation
- typically uses straightforward transfer actions or timing optimization
- low to moderate coordination cost

#### scenario b: active

This must use medium-term transfer planning over about 3 years.

Characteristics:
- more deliberate use of gift or staged transfer
- may use recipient segmentation, timing distribution, or phased transfers
- moderate implementation burden
- more meaningful tax planning effect than scenario a
- requires monitoring of timing and execution discipline

#### scenario c: comprehensive

This must include structural options where acceptable, such as family corporation review or broader ownership restructuring.

Characteristics:
- highest complexity
- potentially broader planning benefits
- includes tax, legal, governance, and operating considerations
- appropriate only when the client accepts structural change and ongoing management burden

The three scenarios must differ materially. Do not present small variations of the same idea.

### 6. build each scenario with the same evaluation dimensions

For each scenario, provide:

- strategy name
- execution method
- estimated annual tax saving or planning benefit where possible
- execution difficulty
- cost level
- caution points

Use practical difficulty levels such as:

- low
- medium
- high

For cost, use concise operational language such as:

- low
- medium
- high
- plus short note if driven by tax advisory, legal work, valuation, setup, or maintenance cost

### 7. create a separate transfer-method comparison table

After the scenario table, provide a comparison across transfer methods.

Default methods to compare when relevant:

- lifetime gift
- inheritance
- phased gift
- family corporation route
- other structural transfer route if relevant to the facts

For each method, compare:

- transfer method
- target asset
- estimated tax burden
- tax efficiency or planning advantage
- practical caution points

The comparison must make differences visible, not merely descriptive.

### 8. interpret tax effect properly

When discussing tax effect, explain what type of advantage is being considered.

Examples:
- gift-tax timing benefit
- inheritance-tax concentration avoidance
- phased use of exemptions or lower taxable concentration
- valuation or control-related planning logic
- income-shifting or governance-related implications where structurally relevant

Do not treat "tax saving" as a single abstract number without explaining the mechanism.

### 9. include non-tax feasibility review

For strategies involving structural change, especially family corporation or more complex transfer routes, include non-tax caution points such as:

- legal setup requirements
- governance burden
- accounting and compliance cost
- maintenance complexity
- scrutiny risk if substance is weak
- operational burden for family members

Do not recommend structural options as automatically superior just because they may look tax-efficient.

### 10. produce the required tables

Default scenario table:

| 전략명 | 실행 방법 | 예상 절세액(연) | 실행 난이도 | 소요 비용 | 유의사항 |

Default transfer comparison table:

| 이전 방법 | 이전 대상 자산 | 예상 세부담 | 절세 효과 | 실행 시 유의사항 |

Use korean in the final output tables unless the user asks for another language.

### 11. add assumptions, limits, and follow-up review points

When needed, add short sections below the tables for:

- assumptions
- limitations
- missing information
- issues requiring tax or legal specialist review
- items needing valuation or document confirmation

This is especially important when the user gives only partial client information.

## output rules

### default output

Provide, in this order:

1. client facts summary
2. assumptions
3. scenario table
4. transfer-method comparison table
5. key commentary
6. limitations and additional review points

### output style

Write like a planning memo or pb consultation draft.

Prefer:

- short, structured statements
- explicit planning assumptions
- differentiated scenarios
- practical tax logic
- operationally useful cautions
- clear comparison language

Avoid:

- generic textbook tax explanations
- overconfident numbers
- repeating the same caution for every strategy
- abstract “consult a professional” language without specific next-step context

## validation checklist

Before finalizing, confirm all of the following:

- the client facts and assumptions are stated clearly
- scenario a, b, and c are materially different in structure and planning horizon
- estimated tax effect is not overstated or presented as certain
- execution difficulty and cost are practical and comparable
- caution points explain real risks or constraints
- the transfer-method comparison table makes methods meaningfully comparable
- missing facts are explicitly identified where they affect the result
- structural options include legal, tax, and operational caution points

If the available facts are too limited for reliable quantification, reduce precision and explain the limitation.

## scenario design standard

### scenario a standard

This should fit a client who wants simplicity, speed, and low disruption.

Good examples of features:
- immediate execution under existing ownership structure
- limited number of transfer actions
- minimal setup cost
- manageable explanation to the client

### scenario b standard

This should fit a client willing to act over time for better planning efficiency.

Good examples of features:
- staged transfer
- timing-based execution
- recipient diversification
- multi-year planning under current assumptions

### scenario c standard

This should fit a client who accepts complexity for broader strategic planning.

Good examples of features:
- family corporation review
- ownership restructuring
- integrated asset and governance planning
- multi-party coordination
- legal and tax implementation review

Do not include scenario c unless structural change is allowed or worth discussing as an option.

## treatment of estimates

When presenting `예상 절세액(연)` or `예상 세부담`, follow these rules:

- treat values as indicative planning estimates
- explain the main assumptions that drive the estimate
- use ranges when precision is weak
- avoid presenting exact filing-level tax amounts unless the user provided unusually complete facts and the basis is clear
- distinguish between annual saving and total life-cycle tax effect

Use wording such as:

- estimated annual planning benefit
- rough annual tax-saving range
- indicative tax burden under stated assumptions
- may vary materially by valuation, ownership history, and implementation timing

## caution-point standard

For the `유의사항` or `실행 시 유의사항` column, include real constraints such as:

- valuation uncertainty
- transfer timing sensitivity
- ownership control issues
- legal documentation burden
- family consent or governance complexity
- subsequent tax exposure
- anti-avoidance scrutiny risk
- setup and maintenance cost
- mismatch between tax efficiency and practical feasibility

Do not use empty phrases such as:
- requires caution
- professional review needed
- legal check required

Make the reason concrete.

## recommended response pattern

Use this sequence unless the user requests a different format:

1. client summary
2. assumptions
3. scenario table
4. transfer-method comparison table
5. strategic commentary
6. limitations and next review items

### example structure

고객 전제 요약:
- ...
- ...

가정:
- ...
- ...

| 전략명 | 실행 방법 | 예상 절세액(연) | 실행 난이도 | 소요 비용 | 유의사항 |
|---|---|---|---|---|---|
| ... | ... | ... | ... | ... | ... |

| 이전 방법 | 이전 대상 자산 | 예상 세부담 | 절세 효과 | 실행 시 유의사항 |
|---|---|---|---|---|
| ... | ... | ... | ... | ... |

핵심 해설:
- ...
- ...

한계 및 추가 검토:
- ...
- ...

## handling broad requests

If the user asks for a general client strategy, default to a full scenario design with a conservative, active, and comprehensive option. Include at least one direct comparison between gift and inheritance unless clearly irrelevant.

## handling narrow requests

If the user asks for only one method, such as gift only or inheritance only, go deeper on that method but still compare it briefly against the nearest alternative if it helps the decision.

## do not do

- do not provide only generic tax education
- do not skip the assumptions section when facts are incomplete
- do not make scenario a, b, and c too similar
- do not present estimated tax amounts as guaranteed outcomes
- do not recommend complex structures without discussing non-tax burden
- do not omit implementation difficulty, cost, or caution points
