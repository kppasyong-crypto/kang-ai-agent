# Response Direction Examples

Response directions should be concrete enough for immediate operational use.

## Better examples

- Update 상담 멘트 to reflect the revised explanation duty for high-risk or complex products.
- Revise the product explanation checklist to capture the newly emphasized disclosure point.
- Add a lending scenario note that reflects the updated DSR or LTV treatment before discussing funding plans.
- Refresh customer-facing handouts and internal FAQs so temporary measures are not confused with standing rules.
- Review whether approval, escalation, or exception handling steps need revision for affected client segments.

## Weaker examples to avoid

- Monitor the situation.
- Be cautious in practice.
- Consider reviewing materials.

## Quality standard

A good response direction should tell the team:

- what to change
- where in the workflow to change it
- why the change matters operationally
