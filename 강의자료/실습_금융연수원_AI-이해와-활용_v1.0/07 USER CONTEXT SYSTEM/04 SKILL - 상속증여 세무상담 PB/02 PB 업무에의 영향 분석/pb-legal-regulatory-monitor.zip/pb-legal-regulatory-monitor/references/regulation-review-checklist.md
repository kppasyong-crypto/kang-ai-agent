# Regulation Review Checklist

Review each candidate item against the checklist below before including it.

## Status and timing

- What is the exact law or regulation name?
- Is the item a law, enforcement decree, notice, rule, guideline, or administrative interpretation?
- Is the change enacted, amended, effective, pending, temporary, deferred, or only proposed?
- What is the effective date?
- Is there a transition rule, grandfathering, or phased implementation?

## Change content

- What specifically changed?
- Is the change about customer protection, product sales, suitability, lending, disclosure, reporting, or operations?
- Is the change permanent or temporary?

## PB work impact

- Does the customer explanation standard change?
- Does the recommendation or sales process change?
- Does suitability or appropriateness review change?
- Does documentation or evidence retention change?
- Does lending consultation or real-estate funding planning change?
- Are some client groups affected more than others?

## Response direction

- What should PBs change immediately in practice?
- Does a script, checklist, FAQ, guide, or customer handout need updating?
- Should the team distinguish temporary measures from standard rules?
- Is a branch or advisory escalation point needed?
