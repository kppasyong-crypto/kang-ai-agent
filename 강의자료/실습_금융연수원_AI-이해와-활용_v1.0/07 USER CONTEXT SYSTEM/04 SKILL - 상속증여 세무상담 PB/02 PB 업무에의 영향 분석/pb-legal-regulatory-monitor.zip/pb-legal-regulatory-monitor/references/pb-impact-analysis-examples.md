# PB Impact Analysis Examples

Use practical impact wording instead of generic summaries.

## Better examples

- Customers subscribing to higher-risk products may require a revised explanation flow and stronger documentation of key risk disclosures.
- Lending consultations for real-estate purchases should reflect the revised DSR treatment before presenting borrowing capacity scenarios.
- Product comparison discussions may need updated wording if the supervisory expectation for disclosure or suitability screening changed.
- PBs handling high-net-worth clients should revisit guidance materials where family wealth transfer or leverage strategies interact with the updated rule.

## Weaker examples to avoid

- There may be business impact.
- Staff should understand the regulation.
- Additional explanation may be needed.

## Test for a strong PB impact sentence

A strong sentence should answer at least one of these:

- What changes in the client conversation?
- What changes in the sales or recommendation process?
- What changes in the documentation or checklist?
- Which client segment is most affected?
