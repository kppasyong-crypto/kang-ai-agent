# Source Priority Guide

Use this order when verifying legal and regulatory developments.

## Priority order

1. Official law text and subordinate regulations
2. Official Financial Services Commission materials
3. Official Financial Supervisory Service materials
4. Government ministry releases directly tied to the rule
5. Official notices, administrative rules, guidelines, FAQs, and explanatory materials
6. Credible news coverage only as a discovery aid

## Working rules

- Do not treat media coverage as the primary legal basis.
- Confirm final status through an official document before describing a change as effective or binding.
- Distinguish law, enforcement decree, notice, guideline, and press release.
- If a rule is temporary or exceptional, say so clearly.
- If multiple official materials differ, prefer the source that establishes legal effect and timing most clearly.

## Uncertainty wording

Use clear status labels such as:

- officially effective as of [date]
- officially announced, but detailed implementation guidance remains limited
- pending final confirmation in official text
- temporary measure subject to extension or review
- public discussion exists, but no final official confirmation was found
