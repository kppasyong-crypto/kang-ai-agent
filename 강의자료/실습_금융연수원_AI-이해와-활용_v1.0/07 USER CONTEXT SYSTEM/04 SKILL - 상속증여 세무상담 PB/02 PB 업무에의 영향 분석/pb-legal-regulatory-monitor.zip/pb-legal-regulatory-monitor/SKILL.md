---
name: pb-legal-regulatory-monitor
description: monitor, verify, and summarize recent korean legal and regulatory developments relevant to private banking work. use when the user asks for financial law amendments, regulatory updates, supervisory guidance changes, effective-date-based compliance summaries, or analysis of how new rules affect pb, wealth management, investment, lending, real estate, customer communications, product suitability, or advisory processes. especially relevant for financial consumer protection act updates, capital markets act enforcement decree changes, ltv dti dsr regulation changes, and new notices, guidelines, or announcements from financial services commission or financial supervisory service.
---

# pb legal regulatory monitor

Follow this skill when the user wants a practical monitoring summary of korean legal or regulatory developments affecting private banking, wealth management, investment advisory, lending consultation, or real-estate-related customer guidance.

Focus on implementation impact, not generic legal explanation. Search first, verify with official sources, then summarize the change, effective date, pb work impact, and recommended response actions.

## scope

Use this skill for one, several, or all of the following:

- financial consumer protection act related changes
- capital markets act enforcement decree changes and related impact
- real estate lending and credit regulations, including ltv, dti, and dsr
- financial services commission notices, rules, announcements, interpretations, and guidance
- financial supervisory service notices, administrative guidance, guidelines, inspection-related guidance, and supervisory updates
- related financial, investment, lending, asset-management, and customer-protection regulatory developments materially relevant to pb work

If the user asks broadly for recent legal or regulatory changes affecting pb work, cover all major relevant areas above.
If the user names a specific law, decree, notice, or topic, stay focused on that area.

## core objective

Produce a work-ready monitoring summary that can be used for:

- pb internal review
- advisory team briefing
- customer communication preparation
- product explanation process review
- lending consultation impact assessment
- internal checklist and process updates

Do not stop at headline summary. For each item, identify:

- what changed
- when it takes effect
- how it changes pb work in practice
- what action or response direction should be taken

## inputs

Expect the following when provided:

- one or more monitoring targets
- optional time period
- optional focus on pb work impact
- optional focus on response direction or action items

If the user does not provide a time range, prioritize the most recent material changes and current effective rules.

## workflow

1. Determine whether the request is broad monitoring or a specific law or rule review.
2. Perform fresh research before drafting.
3. Verify the legal or supervisory status through official sources.
4. Distinguish change content, effective date, pb work impact, and response direction.
5. Produce a table-first answer, then add short practical commentary if needed.

## mandatory workflow

### 1. determine the monitoring scope

Resolve the request into:

- full monitoring scope vs specific law or regulation
- law / enforcement decree / notice / guideline / administrative guidance
- change summary only vs impact analysis vs response plan
- whether the user wants a table only or table plus commentary

If the request is broad, default to a comparison table with short implementation notes.

### 2. perform fresh research first

Always perform current research before drafting the answer.

Prioritize primary and official sources in this order whenever available:

1. official law text and subordinate regulations
2. financial services commission
3. financial supervisory service
4. ministry or government policy release directly tied to the rule
5. official public notices, administrative rules, explanatory materials, or press releases

Use news articles only to discover topics or public reactions. Do not rely on them alone for legal or regulatory conclusions.

When a change appears in media coverage, confirm the legal status through an official source before presenting it as effective or final.

### 3. verify regulatory status

Before including an item, identify its status as precisely as possible:

- enacted
- amended
- announced
- effective
- pending
- proposed
- temporarily applied
- extended
- deferred
- interpreted through guidance rather than formal amendment

Do not present a proposal, consultation draft, or unofficial market rumor as finalized regulation.

If a rule is temporary, exceptional, or policy-driven rather than permanent institutional reform, say so clearly.

### 4. classify the type of change

For each item, determine which of the following best describes the change:

- statutory amendment
- enforcement decree or rule revision
- supervisory notice or guideline update
- lending regulation threshold or treatment change
- sales process or explanation-duty change
- suitability / appropriateness / disclosure expectation change
- reporting, documentation, or operational process change
- temporary relief or temporary tightening measure

Use practical labels when helpful, but preserve legal meaning.

### 5. extract the mandatory analysis fields

For each included item, gather and verify:

- law or regulation name
- major change content
- effective date
- pb work impact
- response direction

Do not leave these fields generic when official materials allow more precision.

Good examples:

- which obligation changed
- which customer interaction step is affected
- which product recommendation or explanation script must be reviewed
- whether suitability assessment or documentation standards change
- whether lending consultation assumptions must be updated
- whether customer-facing material must be revised

### 6. interpret impact from a pb workflow perspective

Translate the rule change into actual pb work.

Possible pb impact areas include:

- customer explanation duty
- recommendation and sales process
- suitability or appropriateness judgment
- product comparison and disclosure
- investment risk explanation
- lending consultation and debt planning
- real estate purchase funding discussion
- document retention or evidence collection
- customer notice wording
- internal escalation or exception handling

Do not merely restate the legal text. Explain what changes in day-to-day pb practice.

### 7. derive action-oriented response direction

For each item, provide a response direction that can be acted on by a pb team or advisory organization.

Good response directions often include:

- revise counseling scripts
- update product explanation checklist
- review suitability or appropriateness questions
- adjust lending consultation assumptions
- update customer guide materials
- revise internal review points
- prepare faq for clients likely to be affected
- separate temporary measures from standing rules in internal documents

Avoid vague phrases like:

- monitor continuously
- be cautious
- consider response

Replace them with concrete next actions.

### 8. produce the required output table

Default to this format:

| 법령·규제명 | 주요 변경 내용 | 시행일 | PB 업무 영향 | 대응 방향 |

Use korean in the output table unless the user requests another language.

Keep table cells concise but practically usable.

### 9. add short commentary when necessary

Add commentary below the table when one or more of the following applies:

- the legal status is easily misunderstood
- there is a gap between headline interpretation and actual operational effect
- a temporary measure may be mistaken for a permanent regime change
- multiple rules interact with each other
- the user asked for internal briefing or pb response planning

Use commentary to clarify timing, boundaries, and implications.

## output rules

### default output

Provide:

1. a regulatory analysis table
2. short practical commentary
3. source-backed support from official materials

### output style

Write for working professionals who need to act on the information.

Prefer:

- exact law or regulation names
- clear distinction between change content and work impact
- explicit effective dates
- concrete action directions
- concise and precise language

Avoid:

- long generic summaries of the legal background
- unsupported interpretation
- article-only summaries
- abstract compliance language without practical meaning

## validation checklist

Before finalizing, confirm all of the following:

- every row includes an effective date, or clearly says effective date not confirmed
- every row describes an actual change, not only a topic headline
- pb work impact is operational, not generic
- response direction is actionable, not abstract
- the status of the item is clear: final, pending, temporary, deferred, or interpretive
- official sources were checked first
- any uncertainty or interpretive ambiguity is clearly labeled

If a point cannot be fully confirmed, say so explicitly rather than guessing.

## pb work impact standard

For the `pb work impact` column, explain how the change affects actual client-facing or internal pb activity.

Good pb work impacts usually address one or more of these:

- whether the customer explanation standard changes
- whether a product can be recommended in the same way as before
- whether documentation or evidence requirements change
- whether the timing of customer action matters
- whether lending limits, funding assumptions, or real estate planning logic changes
- whether specific client groups are more affected, such as high-net-worth clients, leveraged investors, real-estate buyers, retirees, or aggressive investment clients

Do not write generic statements such as:

- there may be business impact
- employees should understand the change
- additional explanation may be needed

Use concrete operational implications.

## response-direction standard

For the `response direction` column, provide measures that can realistically be used in a pb team, branch, advisory center, or internal briefing.

Good examples:

- update 상담 멘트 for customers purchasing high-risk products
- revise suitability checklist questions for certain product categories
- add a lending scenario note reflecting the revised dsr treatment
- refresh customer handout language and internal faq
- separate temporary real-estate credit easing from normal lending standards in briefing materials
- review whether approval or review checkpoints should change for a specific customer segment

Do not use generic or non-executable wording.

## handling uncertainty

When the legal or supervisory meaning is not fully settled, say so clearly.

Use formulations such as:

- officially announced, but detailed operational guidance remains limited
- effective date confirmed, but branch-level implementation details may vary
- publicly discussed, but final official text not confirmed
- temporary measure subject to later review or extension
- interpretive ambiguity remains in application to specific client scenarios

Do not force certainty where the official material does not provide it.

## resources

When needed, consult these bundled references:

- `references/source-priority-guide.md` for source ranking and verification rules
- `references/regulation-review-checklist.md` for item-by-item review checks
- `references/pb-impact-analysis-examples.md` for strong vs weak pb impact phrasing
- `references/response-direction-examples.md` for actionable response wording

## source discipline

Always prefer primary sources.

Examples of high-priority source types:

- statute text
- enforcement decree text
- official notice or administrative rule
- official guideline or supervisory release
- fsc announcement
- fss announcement
- official faq or explanatory release
- official press release tied to the actual rule

Use secondary reporting only to identify issues or market response. Confirm legal and regulatory status with official documentation before drawing conclusions.

If multiple official materials differ in emphasis, prioritize the source that best establishes binding status and effective timing, and explain the difference briefly if needed.

## recommended response pattern

Use this order unless the user requests a different format:

1. one-line scope statement
2. analysis table
3. key operational commentary
4. brief source note

### example structure

Scope: recent official legal and regulatory developments relevant to [requested area], organized for pb operational review.

| 법령·규제명 | 주요 변경 내용 | 시행일 | PB 업무 영향 | 대응 방향 |
|---|---|---|---|---|
| ... | ... | ... | ... | ... |

핵심 해설:
- ...
- ...

출처 기준:
- official legal and supervisory materials prioritized
- uncertain or pending items explicitly marked

## handling broad requests

If the user asks for “최근 규제 변화” or “pb 업무 관련 법률 업데이트”, do not answer with only one popular topic. Review all requested monitoring categories and include each material official development. If some monitored areas show no confirmed material update in the requested period, say so.

## handling narrow requests

If the user asks about one law, one decree, or one regulatory topic, stay focused and go deeper on:

- legal status
- effective date
- operational impact
- response actions
- temporary vs standing nature of the change

## citation behavior

Cite the supporting official source for each substantive section whenever possible. If a secondary source is used for context, do not let it carry the legal conclusion by itself.

## do not do

- do not answer from memory without fresh research
- do not present unofficial commentary as law or binding rule
- do not omit effective dates
- do not confuse laws, decrees, notices, and guidance documents
- do not write pb work impact as a generic summary
- do not write response direction as an abstract recommendation
