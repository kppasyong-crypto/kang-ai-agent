# tax category checklist

Use this checklist when the user asks for a full-scope review.

## categories to review

- 종합소득세
- 양도소득세
- 상속·증여세
- 금융소득종합과세 기준
- isa·연금계좌 세제혜택
- 해외주식 과세 체계
- 가상자산 과세 체계

## review points for each category

Check whether 2025 to 2026 includes any confirmed change in:

- 제도 구조
- 과세 대상
- 공제, 비과세, 세액공제, 감면
- 한도, 기준금액, 세율
- 시행일
- 경과조치
- 대상 고객군 영향

## practical prompt to self

For each category, ask:

- what rule applied before the change?
- what rule applies after the change?
- when does the new rule apply?
- is there a grandfathering or deferment issue?
- what would a PB need to explain to a client immediately?
