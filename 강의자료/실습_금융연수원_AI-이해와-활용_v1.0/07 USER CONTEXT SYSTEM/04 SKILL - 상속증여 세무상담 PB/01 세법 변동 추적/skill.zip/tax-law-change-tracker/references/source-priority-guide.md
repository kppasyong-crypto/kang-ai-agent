# source priority guide

Use this guide to decide which sources carry the most weight when summarizing korean tax law changes.

## priority order

1. official law text and official legal databases reflecting enacted law
2. enforcement decree and enforcement rule text
3. ministry of economy and finance materials
4. national tax service guidance, faq, or official explanatory notes
5. other government or public agency releases
6. official legislative explanatory materials
7. news and expert commentary only for discovery or context

## practical rule

Do not treat a media summary as the final legal basis if an official source can be checked.

## when sources conflict

Prefer the source that most directly reflects:

- enacted text
- actual effective date
- actual transition rule
- taxpayer-facing administrative guidance

If wording differs across official sources and the difference affects interpretation, explain the discrepancy briefly in the final answer.

## safe wording for uncertainty

Use phrases such as:

- official basis confirmed as of [date]
- official final text not confirmed
- effective date subject to transition rule
- public discussion exists, but official confirmation is limited
