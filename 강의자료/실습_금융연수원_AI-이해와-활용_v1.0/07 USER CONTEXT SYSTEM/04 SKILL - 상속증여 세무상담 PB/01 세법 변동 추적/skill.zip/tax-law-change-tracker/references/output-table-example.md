# output table example

Use this as the default comparison structure.

| 세목 | 항목 | 변경 전 | 변경 후 | 시행일 | PB 상담 포인트 |
|---|---|---|---|---|---|
| 양도소득세 | 특정 과세 기준 | 기존 기준 A 적용 | 개정 기준 B 적용 | 2026-01-01 | 매도 시점에 따라 적용 규정이 달라질 수 있으므로 예정 매각 고객은 거래 시기와 보유 구조를 함께 점검할 필요가 있음 |

## writing standard

- `변경 전` and `변경 후` must be directly comparable.
- `시행일` should be specific whenever possible.
- `PB 상담 포인트` should explain client impact, timing, account choice, reporting burden, or segment-specific implications.

## weak vs strong advisory points

Weak:

- 세 부담 변화 가능성 있음
- 상담 필요

Strong:

- 고액자산가 고객은 적용 시점 전후의 증여·매각 일정에 따라 세후 결과가 달라질 수 있으므로 실행 시점 점검이 필요함
- 연금계좌 활용 고객은 납입 한도와 세액공제 적용 범위를 함께 설명해야 실제 절세 체감과 기대치 차이를 줄일 수 있음
