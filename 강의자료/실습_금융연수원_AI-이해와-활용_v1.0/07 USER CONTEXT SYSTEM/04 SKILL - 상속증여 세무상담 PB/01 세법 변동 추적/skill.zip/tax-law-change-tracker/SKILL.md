---
name: tax-law-change-tracker
description: search, verify, compare, and summarize major korean tax law changes enacted, amended, announced by official authorities, or effective during 2025 to 2026. use when the user asks for tax revisions, tax benefit changes, taxation threshold updates, effective-date-based tax updates, before-and-after comparisons, or pb-ready summaries for private banking, wealth management, customer explanations, or advisory materials. especially relevant for comprehensive income tax, capital gains tax, inheritance and gift tax, financial income aggregation thresholds, isa and pension account tax benefits, and overseas stock or virtual asset taxation changes.
---

# tax law change tracker

Use this skill to produce practical, comparison-based summaries of major Korean tax law changes for 2025 to 2026.

This skill is for working-level advisory output, not generic tax education. Search first, verify with official sources, then organize the result so a PB or wealth manager can use it immediately in consultation or customer-facing materials.

## default scope

Cover the user-requested scope within these tax categories:

- 종합소득세
- 양도소득세
- 상속·증여세
- 금융소득종합과세 기준
- isa·연금계좌 세제혜택
- 해외주식 과세 체계
- 가상자산 과세 체계

If the user asks broadly for recent tax changes after 2025, review all categories above.
If the user specifies one or more categories, stay focused on those categories.

## output objective

For each confirmed in-scope change, identify:

- what changed
- what the previous rule, threshold, rate, benefit, or tax treatment was
- what the new rule, threshold, rate, benefit, or tax treatment is
- when the change takes effect
- what a PB should explain, caution, or emphasize to the client

Do not stop at headline summaries. Produce material that can be used as a PB briefing draft, client explanation note, or wealth-management consultation aid.

## workflow

### 1. resolve the request

Determine:

- full-scope review vs specific tax category review
- enactment-based summary vs effective-date-based summary
- whether a particular cutoff date matters
- whether PB advisory emphasis is required
- whether the user wants only the table or table plus commentary

If the request is broad or ambiguous, default to:

1. one-line scope statement
2. comparison table
3. short practical commentary
4. source note

### 2. search current information first

Always perform fresh web research before drafting the answer.

Prioritize sources in this order whenever available:

1. official law text and legal databases reflecting enacted law
2. ministry of economy and finance
3. national tax service
4. other government or public agency materials
5. official press releases, explanatory materials, or legislative summaries

Use news, commentary, and blogs only as discovery aids or background context. Never rely on them alone for a legal conclusion.

### 3. verify that the item is in scope for 2025 to 2026

Include only items that are clearly one of the following:

- enacted in 2025 or 2026
- amended in 2025 or 2026
- effective in 2025 or 2026
- subject to a transition rule, postponement, staged implementation, or deferred application that materially affects 2025 to 2026 practice

If a topic was discussed publicly but was postponed, pending, not yet finalized, or not officially confirmed, do not present it as a completed law change. Label the status clearly.

### 4. classify the change

Frame each change in a comparison-friendly way. Use one or more of these practical lenses when useful:

- 제도 변경
- 과세 대상 변경
- 공제·한도·세율 기준 변경
- 시행일 및 경과조치

Use plain professional wording that a PB can explain easily without distorting legal meaning.

### 5. extract the required comparison elements

For every row, gather and verify:

- 세목
- 항목
- 변경 전
- 변경 후
- 시행일
- PB 상담 포인트

Do not leave a row vague when the source permits specificity.

Prefer concrete comparisons such as:

- threshold before vs threshold after
- rate before vs rate after
- eligible taxpayer or account type before vs after
- taxable scope before vs after
- implementation timing and grandfathering
- which client segment is newly affected or newly excluded

### 6. check transition rules and practical exceptions

Actively look for:

- acquisition-date based rules
- filing-period based rules
- grandfathering
- staged implementation
- deferred enforcement
- account-type, asset-type, or taxpayer-type exceptions

If transition rules materially change practical interpretation, mention them in the table or in a short note below it.

### 7. build the table

Use this default table format unless the user requests otherwise:

| 세목 | 항목 | 변경 전 | 변경 후 | 시행일 | PB 상담 포인트 |

Output the table in Korean unless the user requests another language.

Write comparison fields in concise, parallel phrasing so the reader can quickly scan the differences.

### 8. add short commentary when needed

Add a short explanation below the table when one or more of these applies:

- several changes interact with each other
- transition rules are important
- public discussion differs from actual implementation status
- PB explanation points need consolidation
- the user asks for client-facing guidance or a briefing memo style

Commentary should clarify or synthesize. Do not repeat the table mechanically.

## validation rules

Before finalizing, verify all of the following:

- every row has an 시행일, or clearly states that the effective date is unconfirmed or pending
- every row has a true 변경 전 / 변경 후 comparison
- each PB 상담 포인트 contains a practical advisory implication, not a generic restatement
- each included item actually belongs to 2025 to 2026 by enactment, amendment, effectiveness, or transitional relevance
- official sources were prioritized
- uncertain, deferred, proposed, or pending items are labeled explicitly

If any element cannot be confirmed, say so directly rather than guessing.

## standard for pb advisory points

The `PB 상담 포인트` column should help a relationship manager explain real client impact.

Good advisory points usually address one or more of these:

- who is newly affected or no longer affected
- whether tax timing matters for sale, transfer, subscription, redemption, or withdrawal
- whether account choice should be reconsidered
- whether rebalancing or disposal timing may need review
- whether reporting, withholding, filing, or documentation burden changes
- whether high-net-worth clients, retirees, family wealth-transfer clients, overseas investors, or digital-asset investors are especially affected

Avoid generic phrases such as:

- 세 부담이 달라질 수 있음
- 유의 필요
- 상담 필요

Replace them with concrete implications tied to taxpayer behavior or advisory timing.

## treatment of uncertainty

When the legal or administrative position is not fully settled, say so explicitly.

Use wording like:

- 공식 시행 기준 확인
- 공식 확정 근거 미확인
- 시행 유예 또는 경과조치 적용
- 언론 보도는 있으나 공식 근거 기준으로는 확정 표현 곤란

Never convert a proposal, rumor, or postponed regime into a finalized change.

## source discipline

When multiple sources exist, prefer the source that best reflects enacted law and actual application timing.

Use official materials such as:

- law text
- enforcement decree or rule
- ministry press release
- national tax service guidance
- official faq or explanatory material
- legislative explanatory note

Use secondary sources only for context or discovery. Confirm the legal status with official material before stating the rule.

If official materials differ in wording, explain the difference briefly if it affects practical interpretation.

## response pattern

Use this sequence unless the user asks for a different structure:

1. one-line scope statement
2. comparison table
3. key practical commentary
4. brief source note

Example structure:

Scope: 2025~2026년 시행·개정 또는 경과조치가 실무상 중요한 [세목] 변동 사항을 PB 상담 관점으로 정리함.

| 세목 | 항목 | 변경 전 | 변경 후 | 시행일 | PB 상담 포인트 |
|---|---|---|---|---|---|
| ... | ... | ... | ... | ... | ... |

핵심 해설:
- ...
- ...

출처 기준:
- 법령, 정부부처, 국세청, 공공기관 자료 우선
- 불확실 항목은 명시

## handling broad requests

If the user asks for `2025년 이후 세법 개정`, `최근 세법 변화`, or a similarly broad request, do not answer with only a few famous topics. Review the full supported category set. If a category has no clearly confirmed in-scope major change, say so.

## handling narrow requests

If the user asks for one category only, do not dilute the answer with unrelated taxes. Go deeper on:

- detailed before and after comparison
- taxpayer segments affected
- transition rules
- PB explanation points

## do not do

- do not answer from memory without fresh research
- do not include changes outside 2025 to 2026 unless needed for the before-comparison baseline
- do not present proposals or speculation as finalized law
- do not omit 시행일
- do not omit the PB advisory perspective when the request is practical or advisory in nature
- do not rely on blogs or news alone when official support can be checked
